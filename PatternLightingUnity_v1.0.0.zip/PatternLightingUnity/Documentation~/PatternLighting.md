# Pattern Lighting System Documentation

## Overview

Pattern Lighting System is a comprehensive lighting, water, and materials package for Unity 6 with URP support.

## Table of Contents

1. [Installation](#installation)
2. [Quick Start](#quick-start)
3. [Pattern Light](#pattern-light)
4. [Water System](#water-system)
5. [Shadow System](#shadow-system)
6. [Materials](#materials)
7. [API Reference](#api-reference)
8. [Performance](#performance)

## Installation

### Requirements
- Unity 6 (6000.0 or higher)
- Universal Render Pipeline 17.0+

### Via Package Manager
1. Open Window → Package Manager
2. Click + → Add package from git URL
3. Enter the repository URL
4. Click Add

## Quick Start

### Creating Your First Pattern Light

```csharp
using UnityEngine;
using PatternLighting;

public class QuickStart : MonoBehaviour
{
    void Start()
    {
        // Create a pattern light
        GameObject lightObj = new GameObject("My Pattern Light");
        Light light = lightObj.AddComponent<Light>();
        light.type = LightType.Point;
        light.intensity = 5;
        light.range = 10;
        
        PatternLight patternLight = lightObj.AddComponent<PatternLight>();
        patternLight.settings.pattern = LightPattern.Fire;
        patternLight.baseColor = new Color(1, 0.5f, 0.1f);
    }
}
```

## Pattern Light

### Component Properties

| Property | Type | Description |
|----------|------|-------------|
| settings | PatternLightSettings | Pattern configuration |
| baseColor | Color | Base light color |
| baseIntensity | float | Base intensity multiplier |
| castPatternShadows | bool | Enable shadow casting |
| syncGroup | string | Sync group name |

### Pattern Types

```csharp
public enum LightPattern
{
    Steady,      // Constant
    Pulse,       // Sine wave
    Flicker,     // Random
    Strobe,      // Binary on/off
    Candle,      // Organic flame
    Fluorescent, // Startup effect
    Lightning,   // Flash
    Fire,        // Complex flicker
    Alarm,       // Emergency
    Underwater,  // Caustics
    Heartbeat,   // Medical
    Breathing,   // Slow fade
    Custom       // Use AnimationCurve
}
```

### Methods

```csharp
// Trigger flash effect
void TriggerFlash(float duration = 0.1f, float intensity = 10f)

// Sync with another light
void SyncWith(PatternLight other)

// Change pattern at runtime
void SetPattern(LightPattern pattern)

// Change speed
void SetSpeed(float speed)
```

## Water System

### Creating Water

```csharp
// Create water plane
GameObject waterObj = GameObject.CreatePrimitive(PrimitiveType.Plane);
waterObj.transform.localScale = new Vector3(10, 1, 10);

PatternWater water = waterObj.AddComponent<PatternWater>();
water.settings.quality = WaterQuality.High;
water.settings.waveHeight = 0.5f;
water.settings.enableReflections = true;
water.settings.enableFoam = true;
```

### Water Settings

| Property | Description |
|----------|-------------|
| quality | Quality preset |
| waveHeight | Wave amplitude |
| waveSpeed | Animation speed |
| waveScale | Wave frequency |
| shallowColor | Near-shore color |
| deepColor | Deep water color |
| transparency | Water clarity |
| enableReflections | Planar reflections |
| enableFoam | Shore foam |
| enableCaustics | Underwater caustics |

### Querying Water

```csharp
PatternWater water = GetComponent<PatternWater>();

// Get wave height at position
float height = water.GetWaveHeightAt(transform.position);

// Check if underwater
bool underwater = water.IsUnderwater(transform.position);
```

## Shadow System

### PatternShadow Component

```csharp
PatternShadow shadow = directionalLight.AddComponent<PatternShadow>();
shadow.settings.quality = ShadowQuality.High;
shadow.settings.intensity = 1.0f;
shadow.settings.softness = 1.0f;
shadow.settings.contactShadows = true;
```

### Contact Shadow Volume

```csharp
// Create volume for detailed contact shadows
GameObject volume = new GameObject("Contact Shadow Volume");
BoxCollider collider = volume.AddComponent<BoxCollider>();
collider.size = new Vector3(10, 10, 10);

ContactShadowVolume csv = volume.AddComponent<ContactShadowVolume>();
csv.intensity = 1.0f;
csv.length = 0.1f;
```

## Materials

### PBR Material

Create via script:
```csharp
Material mat = new Material(Shader.Find("Pattern Lighting/PBR"));
mat.SetColor("_BaseColor", Color.white);
mat.SetFloat("_Metallic", 0.5f);
mat.SetFloat("_Smoothness", 0.7f);
mat.SetFloat("_UsePatternEmission", 1);
mat.SetFloat("_PatternType", (float)LightPattern.Pulse);
```

### Emissive Material

```csharp
Material mat = new Material(Shader.Find("Pattern Lighting/Emissive"));
mat.SetColor("_EmissionColor", Color.red * 5);
mat.SetFloat("_PatternType", (float)LightPattern.Alarm);
mat.SetFloat("_PatternSpeed", 2.0f);
```

## API Reference

### PatternLightingManager

```csharp
// Get singleton
var manager = PatternLightingManager.Instance;

// Query lights
var lights = manager.GetLightsAtPosition(position, radius);
float intensity = manager.GetCombinedIntensityAt(position);
Color color = manager.GetCombinedColorAt(position);

// Global control
manager.SetGlobalIntensity(1.5f);
manager.SetGlobalSpeed(2.0f);
manager.TriggerFlashAtPosition(position, 10f, 0.1f, 5f);
manager.SyncGroup("MyGroup");
```

### PatternEvaluator

```csharp
// Evaluate pattern value
float value = PatternEvaluator.Evaluate(
    LightPattern.Fire, 
    Time.time, 
    transform.position
);
```

## Performance

### Optimization Tips

1. **Use Sync Groups** - Reduces per-light calculations
2. **Quality Settings** - Use lower quality for distant objects
3. **Reflection Downsample** - Reduce reflection resolution
4. **Disable Unused Features** - Turn off foam/caustics when not needed

### Profiling

```csharp
// Enable debug mode
PatternLightingManager.Instance.showDebugInfo = true;

// Get stats
string stats = PatternLightingManager.Instance.GetStatsString();
Debug.Log(stats);
```

## Support

For issues and feature requests, visit:
https://github.com/PULOTIGE/VOXELCRAI
