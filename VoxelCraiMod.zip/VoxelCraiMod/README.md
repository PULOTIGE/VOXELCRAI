# 🚀 VoxelCrai Mod

**Продвинутое воксельное освещение для Minecraft на основе паттернов LightPattern1KB**

![Minecraft](https://img.shields.io/badge/Minecraft-1.21.3+-green)
![Fabric](https://img.shields.io/badge/Fabric-0.16+-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 📋 Описание

VoxelCrai Mod добавляет систему продвинутого освещения на основе Spherical Harmonics (SH), вдохновлённую Rethinking Voxels шейдерами, но без ray tracing - чистая оценка паттернов для производительности 60+ FPS.

### ✨ Особенности

- 🎨 **10,000 LightPattern1KB** - Динамические паттерны освещения (1024 байта каждый)
- 🌐 **SH-based GI** - Глобальное освещение через Spherical Harmonics (3-5 полос)
- 🌑 **Мягкие тени** - SH-аппроксимация без ray tracing
- ✨ **Приближённые отражения** - SH specular для металлических поверхностей
- ⚡ **60+ FPS** - Оптимизировано для AMD Radeon VII (1080p)

## 🔧 Требования

- Minecraft 1.21.3+
- Fabric Loader 0.16+
- Fabric API
- Java 21+
- **Рекомендуется:** Iris 1.7+, Sodium 0.6+

## 📦 Установка

### 1. Установка мода

1. Скачайте последний релиз из [Releases](https://github.com/PULOTIGE/VOXELCRAI/releases)
2. Поместите `.jar` файл в папку `mods/`
3. Запустите Minecraft с Fabric

### 2. Активация шейдерпака

Мод автоматически создаёт шейдерпак `VoxelCrai-Shaders` в папке `shaderpacks/`.

1. Откройте настройки видео → Шейдеры (требуется Iris)
2. Выберите `VoxelCrai-Shaders`
3. Настройте параметры в меню шейдеров

## ⚙️ Конфигурация

Файл конфигурации: `config/voxelcrai.json`

```json
{
  "patternCount": 10000,        // 1000-10000 паттернов
  "shBands": 3,                 // 2-5 полос SH
  "enableGI": true,             // Глобальное освещение
  "enableShadows": true,        // Тени
  "enableReflections": true,    // Отражения
  "giIntensity": 1.0,           // 0.0-2.0
  "shadowSoftness": 0.5,        // 0.0-1.0
  "reflectionIntensity": 0.8    // 0.0-1.0
}
```

### Настройки в шейдерпаке

| Параметр | Описание | Значения |
|----------|----------|----------|
| `PATTERN_COUNT` | Количество паттернов | 1000-10000 |
| `SH_BANDS` | Полосы SH | 2-5 |
| `GI_INTENSITY` | Интенсивность GI | 0.0-2.0 |
| `SHADOW_SOFTNESS` | Мягкость теней | 0.0-1.0 |
| `REFLECTION_INTENSITY` | Интенсивность отражений | 0.0-1.0 |

## 🎨 Структура LightPattern1KB

```
┌─────────────────────────────────────────────────────────────┐
│ LightPattern1KB (1024 bytes, aligned for GPU)               │
├─────────────────────────────────────────────────────────────┤
│ id              [8 bytes]  - Уникальный ID паттерна         │
│ _pad0           [8 bytes]  - Выравнивание                   │
│ direct_light    [6 bytes]  - RGB fp16 прямой свет           │
│ indirect_light  [6 bytes]  - RGB fp16 непрямой свет         │
│ sh_coeffs       [9 bytes]  - SH коэффициенты (3 bands)      │
│ roughness       [1 byte]   - Шероховатость материала        │
│ metallic        [1 byte]   - Металличность материала        │
│ flags           [2 bytes]  - Флаги (emissive, transparent)  │
│ sh_band4        [7 bytes]  - 4-я полоса SH (опционально)    │
│ sh_band5        [9 bytes]  - 5-я полоса SH (опционально)    │
│ position        [20 bytes] - Chunk/local позиция            │
│ _padding        [947 bytes]- Padding до 1024                │
└─────────────────────────────────────────────────────────────┘
```

## 🌐 Spherical Harmonics (SH)

Мы используем SH для компактного представления освещения:

- **Band 0 (l=0)**: DC term - ambient освещение
- **Band 1 (l=1)**: Linear terms - направленное освещение
- **Band 2 (l=2)**: Quadratic terms - непрямые отскоки

```glsl
// SH оценка в GLSL
vec3 shEval(float coeffs[9], vec3 dir) {
    float result = coeffs[0] * 0.282095;                    // Band 0
    result += coeffs[1] * 0.488603 * dir.y;                 // Band 1
    result += coeffs[2] * 0.488603 * dir.z;
    result += coeffs[3] * 0.488603 * dir.x;
    result += coeffs[4] * 1.092548 * dir.x * dir.y;         // Band 2
    result += coeffs[5] * 1.092548 * dir.y * dir.z;
    result += coeffs[6] * 0.315392 * (3.0*dir.z*dir.z - 1.0);
    result += coeffs[7] * 1.092548 * dir.x * dir.z;
    result += coeffs[8] * 0.546274 * (dir.x*dir.x - dir.y*dir.y);
    return vec3(max(result, 0.0));
}
```

## 📊 Производительность

Тестирование на AMD Radeon VII (1080p):

| Настройка | FPS | Паттерны | SH Bands |
|-----------|-----|----------|----------|
| Low       | 90+ | 1000     | 2        |
| Medium    | 75+ | 5000     | 3        |
| High      | 60+ | 10000    | 3        |
| Ultra     | 45+ | 10000    | 5        |

## 🔧 Сборка из исходников

```bash
# Клонирование репозитория
git clone https://github.com/PULOTIGE/VOXELCRAI.git
cd VOXELCRAI/VoxelCraiMod

# Сборка
./gradlew build

# JAR файл будет в build/libs/
```

## 📜 Лицензия

MIT License - см. [LICENSE](LICENSE)

## 🙏 Благодарности

- [Rethinking Voxels](https://github.com/gri573/rethinking-voxels) - Вдохновение для архитектуры шейдеров
- [Iris Shaders](https://irisshaders.dev/) - Платформа для шейдеров
- [Sodium](https://modrinth.com/mod/sodium) - Оптимизация рендеринга

## 📞 Контакты

- GitHub: [@PULOTIGE](https://github.com/PULOTIGE)
- Discord: [VoxelCrai Server](https://discord.gg/voxelcrai)

---

**🚀 Сделано с ❤️ командой PULOTIGE**
