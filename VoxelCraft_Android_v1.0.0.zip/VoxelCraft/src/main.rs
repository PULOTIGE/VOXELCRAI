// VoxelCraft - Minecraft-like game
// Desktop entry point

fn main() {
    env_logger::init();
    voxelcraft::run_game();
}
